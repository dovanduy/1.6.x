
# hash value = 73452162
users.enosuchusername='Unknown username: "%s"'


# hash value = 150538340
users.enosuchuserid='Unknown user ID: %d'


# hash value = 144257154
users.enosuchgroupname='Unknown groupname: "%s"'


# hash value = 119129940
users.enosuchgroupid='Unknown group ID: %d'


# hash value = 19526386
users.enoshadowentry='No shadow file entry for "%s"'


# hash value = 266172325
users.eshadownotpermitted='Not enough permissions to access shadow passwo'+
'rd file'

